package weather

import (
	"testing"
	"time"
)

func TestNass(t *testing.T) {
	faelle := []struct {
		menge  float64
		chance int
		nass   bool
	}{
		{0.0, 0, false},
		{0.05, 30, false}, // Nieselei unter der Messchwelle
		{0.05, 60, true},  // wenig Menge, aber der Himmel will es
		{0.2, 10, true},   // gesicherte Menge
		{0.0, 55, true},   // Schwelle erreicht, Menge Null
		{0.0, 54, false},  // knapp darunter
	}
	for _, f := range faelle {
		if got := nass(f.menge, f.chance); got != f.nass {
			t.Errorf("nass(%.2f, %d) = %v, erwartet %v", f.menge, f.chance, got, f.nass)
		}
	}
}

// Stundenreihe ab der laufenden Stunde — der Test darf nicht davon abhängen,
// wann er läuft. Vergangene Stunden filtert rainWindow ohnehin aus.
func stundenReihe(tz string, anzahl int) []string {
	loc, _ := time.LoadLocation(tz)
	start := time.Now().In(loc).Truncate(time.Hour)
	reihe := make([]string, 0, anzahl)
	for i := 0; i < anzahl; i++ {
		reihe = append(reihe, start.Add(time.Duration(i)*time.Hour).Format("2006-01-02T15:04"))
	}
	return reihe
}

func TestRainWindowMitChance(t *testing.T) {
	tz := "Europe/Berlin"

	// 40 Stunden trocken, in fünf Stunden Regen mit hoher Wahrscheinlichkeit,
	// aber nur 0.05 mm — die Wahrscheinlichkeit allein muss das Fenster melden.
	hTimes := stundenReihe(tz, 40)
	hPrecip := make([]float64, len(hTimes))
	hChance := make([]int, len(hTimes))
	for i := range hChance {
		hChance[i] = 20
	}
	for i := range hTimes {
		if i == 5 || i == 6 {
			hChance[i] = 70
			hPrecip[i] = 0.05
		}
	}

	r := rainWindow(nil, nil, hTimes, hPrecip, hChance, tz)
	if r == nil {
		t.Fatal("rainWindow lieferte nil")
	}
	if r.Nass {
		t.Error("jetzt sollte trocken sein")
	}
	loc, _ := time.LoadLocation(tz)
	erwStart := time.Now().In(loc).Truncate(time.Hour).Add(5 * time.Hour)
	if got, _ := time.Parse(time.RFC3339, r.StartsAt); !got.Equal(erwStart) {
		t.Errorf("StartsAt = %v, erwartet %v", got, erwStart)
	}
	if r.Chance != 70 {
		t.Errorf("Chance = %d, erwartet 70", r.Chance)
	}
}

func TestRainWindowMengeSchlaegtChance(t *testing.T) {
	tz := "Europe/Berlin"
	hTimes := stundenReihe(tz, 30)
	hPrecip := make([]float64, len(hTimes))
	hChance := make([]int, len(hTimes))
	for i := range hChance {
		hChance[i] = 10
	}
	hPrecip[4] = 0.6 // gesicherter Schauer, niedrige Chance

	r := rainWindow(nil, nil, hTimes, hPrecip, hChance, tz)
	if r == nil || r.Nass {
		t.Fatalf("Regen nicht erkannt: %+v", r)
	}
	loc, _ := time.LoadLocation(tz)
	erwStart := time.Now().In(loc).Truncate(time.Hour).Add(4 * time.Hour)
	if got, _ := time.Parse(time.RFC3339, r.StartsAt); !got.Equal(erwStart) {
		t.Errorf("StartsAt = %v, erwartet %v", got, erwStart)
	}
}

func TestRegenProTagFenster(t *testing.T) {
	tz := "Europe/Berlin"
	loc, _ := time.LoadLocation(tz)
	jetzt := time.Now().In(loc)
	tag := jetzt.Format("2006-01-02")

	// Der Test braucht eine Stunde davor (vergangener Regen) und zwei danach
	// (kommendes Fenster) im selben Tag. In der Nacht um Mitternacht passt
	// das nicht in einen Tag — dann überspringen wir ihn.
	if jetzt.Hour() < 1 || jetzt.Hour() > 20 {
		t.Skip("braucht Tagesrand mit Platz vor und nach der aktuellen Stunde")
	}

	// Die Reihe beginnt bei Mitternacht des heutigen Tages, wie Open-Meteo.
	mitternacht := time.Date(jetzt.Year(), jetzt.Month(), jetzt.Day(), 0, 0, 0, 0, loc)
	var hTimes []string
	var hPrecip []float64
	var hChance []int
	for i := 0; i < 24; i++ {
		hTimes = append(hTimes, mitternacht.Add(time.Duration(i)*time.Hour).Format("2006-01-02T15:04"))
		hPrecip = append(hPrecip, 0)
		hChance = append(hChance, 10)
	}
	// Vor einer Stunde fiel Regen — vergangen, zählt zur Menge, nicht zum
	// Fenster. In zwei und drei Stunden kommt welcher — das kommende Fenster.
	hPrecip[jetzt.Hour()-1] = 0.6
	hPrecip[jetzt.Hour()+1] = 0.6
	hPrecip[jetzt.Hour()+2] = 0.6

	regen := regenProTag(hTimes, hPrecip, hChance, tz)
	eintrag, ok := regen[tag]
	if !ok {
		t.Fatal("kein Eintrag für heute")
	}
	if eintrag.sum < 1.7 {
		t.Errorf("sum = %.2f, erwartet mindestens 1.7", eintrag.sum)
	}
	erwStart := mitternacht.Add(time.Duration(jetzt.Hour()+1) * time.Hour)
	erwEnde := mitternacht.Add(time.Duration(jetzt.Hour()+2) * time.Hour)
	if got, _ := time.Parse(time.RFC3339, eintrag.start); !got.Equal(erwStart) {
		t.Errorf("start = %v, erwartet %v", got, erwStart)
	}
	if got, _ := time.Parse(time.RFC3339, eintrag.ende); !got.Equal(erwEnde) {
		t.Errorf("ende = %v, erwartet %v", got, erwEnde)
	}
}

func TestRegenProTagVergangenesFenster(t *testing.T) {
	tz := "Europe/Berlin"
	loc, _ := time.LoadLocation(tz)
	jetzt := time.Now().In(loc)
	tag := jetzt.Format("2006-01-02")

	// Später Abend: Regen lag am Vormittag, vorwärts kommt nichts. Das Fenster
	// bleibt dann leer — die Zeile zeigt nur Menge und Prozentwert.
	if jetzt.Hour() < 18 {
		t.Skip("Test prüft den späten Abend")
	}
	mitternacht := time.Date(jetzt.Year(), jetzt.Month(), jetzt.Day(), 0, 0, 0, 0, loc)
	var hTimes []string
	var hPrecip []float64
	var hChance []int
	for i := 0; i < 24; i++ {
		hTimes = append(hTimes, mitternacht.Add(time.Duration(i)*time.Hour).Format("2006-01-02T15:04"))
		hPrecip = append(hPrecip, 0)
		hChance = append(hChance, 5)
	}
	hPrecip[9] = 0.8

	regen := regenProTag(hTimes, hPrecip, hChance, tz)
	eintrag := regen[tag]
	if eintrag.feucht {
		t.Errorf("Fenster sollte leer sein, steht aber %v–%v", eintrag.start, eintrag.ende)
	}
	if eintrag.sum < 0.7 {
		t.Errorf("sum = %.2f, erwartet mindestens 0.7", eintrag.sum)
	}
}
