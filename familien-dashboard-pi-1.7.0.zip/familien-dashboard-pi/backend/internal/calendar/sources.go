package calendar

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"bytes"

	"family-dashboard/backend/internal/auth"
	"github.com/emersion/go-ical"
	"github.com/go-chi/chi/v5"
	"github.com/rs/zerolog/log"
)

// syncInterval bestimmt, wie oft Kalender-Abonnements neu geladen werden. Eine
// Stunde ist entspannt genug für jeden Kalenderserver und frisch genug für
// den Küchentisch — wer sofort braucht, drückt im Adminbereich auf Sync.
const syncInterval = time.Hour

// maxSourceSize begrenzt, was ein Kalender-Abo an Daten liefern darf. Ein
// Familienkalender liegt im Kilobyte-Bereich; fünf Megabytes sind grosszügig
// und halten zugleich einen Fehlgriff auf die falsche URL vom Speicher fern.
const maxSourceSize = 5 << 20

// Source ist ein Kalender-Abo: eine .ics-Adresse aus Apple, Google oder
// Outlook, die das Dashboard selbst nachzieht. Bisher musste jemand die
// Datei von Hand nach data/ics/ kopieren — ein Kalender, der sich heute
// änderte, war morgen im Flur schon veraltet.
type Source struct {
	ID       int        `json:"id"`
	Name     string     `json:"name"`
	URL      string     `json:"url"`
	Color    string     `json:"color"`
	LastSync *time.Time `json:"last_sync,omitempty"`
	Status   string     `json:"status"`
	Error    string     `json:"error,omitempty"`
}

// aboDateiname ist die Datei, in die ein Abo landet. Sie ist gewöhnlichen
// .ics-Dateien im Ordner völlig gleich — genau so soll es sein: Das Einlesen
// kennt nur eine Quelle, den Ordner.
func aboDateiname(id int) string {
	return fmt.Sprintf("abonnement-%d.ics", id)
}

// aboIDausDateiname liest die Abo-ID aus dem Dateinamen zurück. Der Name
// "abonnement-3.ics" gehört zur Quelle 3; jede andere Datei ist von Hand
// abgelegt und bekommt ihre Farbe wie bisher nach Ordnerposition.
func aboIDausDateiname(name string) int {
	base := strings.TrimSuffix(filepath.Base(name), filepath.Ext(name))
	if !strings.HasPrefix(base, "abonnement-") {
		return 0
	}
	id, err := strconv.Atoi(strings.TrimPrefix(base, "abonnement-"))
	if err != nil || id <= 0 {
		return 0
	}
	return id
}

func (s *Service) aboFarben() map[int]string {
	farben := map[int]string{}
	if s.db == nil {
		return farben
	}
	rows, err := s.db.Query(`SELECT id, color FROM calendar_sources`)
	if err != nil {
		return farben
	}
	defer rows.Close()
	for rows.Next() {
		var id int
		var farbe string
		if err := rows.Scan(&id, &farbe); err == nil && farbe != "" {
			farben[id] = farbe
		}
	}
	return farben
}

// ------------------------------------------------------------------- Sync

// syncAllSources holt jedes Abo neu. Ein fehlschlagendes Abo bricht die
// Runde nicht ab — der Rest der Familie bleibt aktuell.
func (s *Service) syncAllSources() {
	if s.db == nil {
		return
	}
	ids, err := s.aboIDs()
	if err != nil {
		log.Error().Err(err).Msg("Failed to list calendar sources for sync")
		return
	}
	for _, id := range ids {
		s.syncSource(id)
	}
}

func (s *Service) aboIDs() ([]int, error) {
	rows, err := s.db.Query(`SELECT id FROM calendar_sources ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []int
	for rows.Next() {
		var id int
		if err := rows.Scan(&id); err == nil {
			ids = append(ids, id)
		}
	}
	return ids, rows.Err()
}

// syncSource lädt ein einzelnes Abo und legt es als .ics-Datei ab. Prüft
// vorher, dass die Antwort wirklich ein Kalender ist — sonst stünde im
// data/ics-Ordner eine HTML-Fehlerseite und der Kalender würde leer.
func (s *Service) syncSource(id int) {
	src, err := s.sourceByID(id)
	if err != nil {
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, src.URL, nil)
	if err != nil {
		s.setSourceError(id, "Adresse lässt sich nicht aufrufen: "+err.Error())
		return
	}
	// Ein paar Kalenderserver verlangen einen kenntlichen Nutzeragenten.
	req.Header.Set("User-Agent", "Familien-Dashboard/1.7 (Kalender-Abo)")

	resp, err := s.client.Do(req)
	if err != nil {
		s.setSourceError(id, "Nicht erreichbar: "+err.Error())
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		s.setSourceError(id, fmt.Sprintf("Server antwortete mit %d", resp.StatusCode))
		return
	}

	body, err := io.ReadAll(io.LimitReader(resp.Body, maxSourceSize+1))
	if err != nil {
		s.setSourceError(id, "Übertragung abgebrochen: "+err.Error())
		return
	}
	if len(body) > maxSourceSize {
		s.setSourceError(id, "Kalender ist grösser als 5 MB")
		return
	}

	if _, err := ical.NewDecoder(bytes.NewReader(body)).Decode(); err != nil {
		s.setSourceError(id, "Das ist keine gültige iCal-Adresse (expected VCALENDAR)")
		return
	}

	datei := filepath.Join(s.icsDir, aboDateiname(id))
	if err := os.WriteFile(datei, body, 0o644); err != nil {
		s.setSourceError(id, "Datei konnte nicht geschrieben werden")
		log.Error().Err(err).Str("file", datei).Msg("Failed to write calendar subscription")
		return
	}

	now := time.Now()
	if _, err := s.db.Exec(`
                        UPDATE calendar_sources
                        SET last_sync = ?, last_status = ?, error = ''
                        WHERE id = ?`,
		now, "OK", id); err != nil {
		log.Error().Err(err).Int("id", id).Msg("Failed to record calendar sync")
	}
	s.parseAll()
	log.Info().Str("name", src.Name).Msg("Calendar subscription synced")
}

func (s *Service) setSourceError(id int, meldung string) {
	if _, err := s.db.Exec(`UPDATE calendar_sources SET last_status = 'Fehler', error = ? WHERE id = ?`,
		meldung, id); err != nil {
		log.Error().Err(err).Int("id", id).Msg("Failed to record calendar error")
	}
	log.Warn().Int("id", id).Str("error", meldung).Msg("Calendar subscription failed")
	s.parseAll()
}

// syncLoop hält die Abos frisch, solange der Server läuft.
func (s *Service) syncLoop(ctx context.Context) {
	s.syncAllSources()
	ticker := time.NewTicker(syncInterval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			s.syncAllSources()
		}
	}
}

// ---------------------------------------------------------------- Handlers

func (s *Service) ListSources(w http.ResponseWriter, r *http.Request) {
	if s.db == nil {
		auth.WriteJSON(w, []Source{})
		return
	}
	rows, err := s.db.Query(`
                        SELECT id, name, url, color, last_sync, last_status, error
                        FROM calendar_sources ORDER BY id`)
	if err != nil {
		auth.HTTPError(w, http.StatusInternalServerError, "Server-Fehler")
		return
	}
	defer rows.Close()

	sources := []Source{}
	for rows.Next() {
		var src Source
		var lastSync sql.NullTime
		if err := rows.Scan(&src.ID, &src.Name, &src.URL, &src.Color,
			&lastSync, &src.Status, &src.Error); err != nil {
			continue
		}
		if lastSync.Valid {
			src.LastSync = &lastSync.Time
		}
		sources = append(sources, src)
	}
	auth.WriteJSON(w, sources)
}

func (s *Service) CreateSource(w http.ResponseWriter, r *http.Request) {
	if s.db == nil {
		auth.HTTPError(w, http.StatusServiceUnavailable, "Kalender-Abos sind nicht verfügbar")
		return
	}
	var req struct {
		Name string `json:"name"`
		URL  string `json:"url"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		auth.HTTPError(w, http.StatusBadRequest, "Ungültige Anfrage")
		return
	}
	req.Name = strings.TrimSpace(req.Name)
	req.URL = strings.TrimSpace(req.URL)
	if req.Name == "" {
		auth.HTTPError(w, http.StatusBadRequest, "Name fehlt")
		return
	}
	if !strings.HasPrefix(req.URL, "http://") && !strings.HasPrefix(req.URL, "https://") {
		auth.HTTPError(w, http.StatusBadRequest, "Adresse muss mit http:// oder https:// beginnen")
		return
	}

	// Farbpalette wie bei den .ics-Dateien: eine feste Reihenfolge, damit zwei
	// Abos nicht die gleiche Farbe tragen.
	var farbe string
	var anzahl int
	if err := s.db.QueryRow(`SELECT COUNT(*) FROM calendar_sources`).Scan(&anzahl); err == nil {
		palette := []string{"#3b82f6", "#ec4899", "#f59e0b", "#10b981", "#8b5cf6", "#ef4444"}
		farbe = palette[anzahl%len(palette)]
	}

	res, err := s.db.Exec(`
                        INSERT INTO calendar_sources (name, url, color) VALUES (?, ?, ?)`,
		req.Name, req.URL, farbe)
	if err != nil {
		log.Error().Err(err).Msg("Failed to create calendar source")
		auth.HTTPError(w, http.StatusInternalServerError, "Abo konnte nicht gespeichert werden")
		return
	}
	id, _ := res.LastInsertId()

	// Sofort holen, damit der Kalender nicht bis zur nächsten Stunde leer bleibt.
	s.syncSource(int(id))

	src, err := s.sourceByID(int(id))
	if err != nil {
		auth.HTTPError(w, http.StatusInternalServerError, "Server-Fehler")
		return
	}
	w.WriteHeader(http.StatusCreated)
	auth.WriteJSON(w, src)
}

func (s *Service) DeleteSource(w http.ResponseWriter, r *http.Request) {
	if s.db == nil {
		auth.HTTPError(w, http.StatusServiceUnavailable, "Kalender-Abos sind nicht verfügbar")
		return
	}
	id, err := strconv.Atoi(chi.URLParam(r, "id"))
	if err != nil {
		auth.HTTPError(w, http.StatusBadRequest, "Ungültige ID")
		return
	}
	if _, err := s.db.Exec(`DELETE FROM calendar_sources WHERE id = ?`, id); err != nil {
		auth.HTTPError(w, http.StatusInternalServerError, "Server-Fehler")
		return
	}
	// Die Datei gehört zum Abo — ohne diesen Schritt bliebe der Kalender
	// als Gespenst weiter stehen.
	if err := os.Remove(filepath.Join(s.icsDir, aboDateiname(id))); err != nil && !os.IsNotExist(err) {
		log.Warn().Err(err).Int("id", id).Msg("Failed to remove subscription file")
	}
	s.parseAll()
	w.WriteHeader(http.StatusNoContent)
}

func (s *Service) SyncOne(w http.ResponseWriter, r *http.Request) {
	if s.db == nil {
		auth.HTTPError(w, http.StatusServiceUnavailable, "Kalender-Abos sind nicht verfügbar")
		return
	}
	id, err := strconv.Atoi(chi.URLParam(r, "id"))
	if err != nil {
		auth.HTTPError(w, http.StatusBadRequest, "Ungültige ID")
		return
	}
	s.syncSource(id)
	src, err := s.sourceByID(id)
	if err != nil {
		auth.HTTPError(w, http.StatusNotFound, "Abo nicht gefunden")
		return
	}
	auth.WriteJSON(w, src)
}

func (s *Service) sourceByID(id int) (Source, error) {
	var src Source
	var lastSync sql.NullTime
	err := s.db.QueryRow(`
                        SELECT id, name, url, color, last_sync, last_status, error
                        FROM calendar_sources WHERE id = ?`, id).
		Scan(&src.ID, &src.Name, &src.URL, &src.Color, &lastSync, &src.Status, &src.Error)
	if lastSync.Valid {
		src.LastSync = &lastSync.Time
	}
	return src, err
}
