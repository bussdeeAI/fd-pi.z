#!/usr/bin/env bash
# Smoke-Test gegen den laufenden Stack (make up).
# Prüft die Kette Traefik -> nginx -> Go-Backend inklusive Login und WebSocket.
set -uo pipefail

BASE="${BASE:-http://localhost:${HTTP_PORT:-8088}}"
JAR="$(mktemp)"
trap 'rm -f "$JAR" "$JAR.txt"' EXIT

pass=0
fail=0
skip=0

# Übersprungen ist nicht dasselbe wie fehlgeschlagen. Auf einer echten
# Installation ist die Standard-PIN längst geändert — dann kommt der Test
# nicht hinein und kann die angemeldeten Prüfungen nicht laufen lassen. Das
# als Fehlschlag zu melden, trainiert einem an, rote Ausgaben zu übergehen.
# Und dann übersieht man das eine Mal, in dem es echt ist.
uebersprungen() {
  printf '  \033[33m—\033[0m %-46s %s\n' "$1" "${2:-übersprungen}"
  skip=$((skip + 1))
}

# Die PIN lässt sich von aussen vorgeben, dann läuft der volle Satz:
#   SMOKE_PIN=1234 make pi-verify
PIN="${SMOKE_PIN:-1234}"

check() {
  local label="$1" expected="$2" actual="$3"
  if [ "$actual" = "$expected" ]; then
    printf '  \033[32m✓\033[0m %-46s %s\n' "$label" "$actual"
    pass=$((pass + 1))
  else
    printf '  \033[31m✗\033[0m %-46s %s (erwartet %s)\n' "$label" "$actual" "$expected"
    fail=$((fail + 1))
  fi
}

code() { curl -s -o /dev/null -w '%{http_code}' "$@"; }

echo ""
echo "Smoke-Test gegen $BASE"
echo ""

echo "Erreichbarkeit"
check "SPA wird ausgeliefert"          200 "$(code "$BASE/")"
check "SPA-Fallback für /settings"     200 "$(code "$BASE/settings")"
check "SPA-Fallback für /rangliste"    200 "$(code "$BASE/rangliste")"
check "SPA-Fallback für /links"        200 "$(code "$BASE/links")"
check "SPA-Fallback für /ansicht"      200 "$(code "$BASE/ansicht")"
check "SPA-Fallback für /wetter"       200 "$(code "$BASE/wetter")"
check "SPA-Fallback für /zeiten"       200 "$(code "$BASE/zeiten")"
check "Manifest"                       200 "$(code "$BASE/manifest.json")"
check "Service Worker"                 200 "$(code "$BASE/service-worker.js")"
check "App-Icon"                       200 "$(code "$BASE/icons/icon-192.png")"
check "Backend-Health über /api"       200 "$(code "$BASE/api/health")"

echo ""
echo "Authentifizierung"
check "Benutzerliste ist öffentlich"   200 "$(code "$BASE/api/auth/users")"
check "Geschützt ohne Login (401)"     401 "$(code "$BASE/api/shopping")"
check "Falsche PIN wird abgewiesen"    401 \
  "$(code -X POST -H 'Content-Type: application/json' -d '{"user_id":1,"pin":"9999"}' "$BASE/api/auth/login")"

# Pick an admin: the later checks need admin-only endpoints. A greedy sed here
# used to grab the LAST id in the array, which was a member.
USER_ID="$(curl -s "$BASE/api/auth/users" | python3 -c '
import json, sys
users = json.load(sys.stdin)
admins = [u["id"] for u in users if u["role"] == "admin"]
print((admins or [u["id"] for u in users] or [1])[0])
' 2>/dev/null || echo 1)"
LOGIN="$(code -c "$JAR" -X POST -H 'Content-Type: application/json' \
  -d "{\"user_id\":${USER_ID:-1},\"pin\":\"$PIN\"}" "$BASE/api/auth/login")"

if [ "$LOGIN" = "200" ]; then
  check "Anmeldung"                    200 "$LOGIN"
else
  uebersprungen "Anmeldung" "PIN passt nicht — das ist auf einer benutzten Installation normal"
fi

if [ "$LOGIN" != "200" ]; then
  echo ""
  echo "  Die angemeldeten Prüfungen brauchen eine gültige PIN. Mit der"
  echo "  richtigen laufen sie mit:"
  echo ""
  echo "      SMOKE_PIN=<vierstellig> $0"
  echo ""
  echo "  Ohne sie werden sie übersprungen — das ist kein Fehlschlag."
else
  echo ""
  echo "Daten-Endpunkte (angemeldet)"
  for ep in me:/api/auth/me weather:/api/weather calendar:/api/calendar \
            shopping:/api/shopping notes:/api/notes chores:/api/chores \
            scoreboard:/api/scoreboard history:/api/scoreboard/history \
            links:/api/links layout:/api/preferences/dashboard.layout \
            reward:/api/shopping/reward location:/api/weather/location \
            devices:/api/devices photos:/api/photos files:/api/files \
            music:/api/music/status musikordner:/api/music/browse \
            zeiten:/api/times wochenplan:/api/times/weekly; do
    name="${ep%%:*}"; path="${ep#*:}"
    status="$(code -b "$JAR" "$BASE$path")"
    # Wetter darf 503 sein, wenn der Server (noch) kein Internet hatte.
    if [ "$name" = "weather" ] && [ "$status" = "503" ]; then
      printf '  \033[33m!\033[0m %-46s 503 (kein Internet – zulässig)\n' "$path"
    else
      check "$path" 200 "$status"
    fi
  done

  echo ""
  echo "Schreiben"
  CREATE="$(curl -s -b "$JAR" -X POST -H 'Content-Type: application/json' \
    -d '{"name":"Smoke-Test","quantity":"1"}' "$BASE/api/shopping")"
  ITEM_ID="$(printf '%s' "$CREATE" | sed -n 's/.*"id":\([0-9]*\).*/\1/p' | head -1)"
  check "Einkaufs-Eintrag anlegen"     201 \
    "$(code -b "$JAR" -X POST -H 'Content-Type: application/json' -d '{"name":"Smoke-Test-2"}' "$BASE/api/shopping")"
  if [ -n "$ITEM_ID" ]; then
    check "Eintrag wieder löschen"     204 "$(code -b "$JAR" -X DELETE "$BASE/api/shopping/$ITEM_ID")"
  fi
  # Aufräumen: jeden Eintrag entfernen, den dieser Test angelegt hat.
  removed=0
  while read -r id; do
    [ -n "$id" ] || continue
    curl -s -o /dev/null -b "$JAR" -X DELETE "$BASE/api/shopping/$id"
    removed=$((removed + 1))
  done < <(curl -s -b "$JAR" "$BASE/api/shopping" \
    | python3 -c 'import json,sys
for item in json.load(sys.stdin):
    if item["name"].startswith("Smoke-Test"):
        print(item["id"])' 2>/dev/null)
  printf '  \033[32m✓\033[0m %-46s %s\n' "Testdaten wieder entfernt" "$removed"
  pass=$((pass + 1))

  echo ""
  echo "Aufgaben"
  # Eine erledigte Aufgabe darf nicht von der nächsten Person noch einmal
  # abgehakt werden — sonst gibt es für einen Müllsack dreimal Punkte.
  CHORE="$(curl -s -b "$JAR" -X POST -H 'Content-Type: application/json' \
    -d '{"title":"Smoke-Test Aufgabe","interval_days":1,"points":1,"rotate":false}' \
    "$BASE/api/chores")"
  CHORE_ID="$(printf '%s' "$CHORE" | sed -n 's/.*"id":\([0-9]*\).*/\1/p' | head -1)"
  if [ -n "$CHORE_ID" ]; then
    check "Aufgabe anlegen"              201 "$(printf '%s' "$CHORE" | grep -q '"id"' && echo 201)"
    check "Einmal abhaken"               200 "$(code -b "$JAR" -X POST "$BASE/api/chores/$CHORE_ID/complete")"
    check "Zweites Abhaken wird abgelehnt" 409 \
      "$(code -b "$JAR" -X POST "$BASE/api/chores/$CHORE_ID/complete")"

    # Der Test darf keine Punkte hinterlassen: die eben vergebenen wieder
    # zurücknehmen, sonst wächst der Punktestand mit jedem Testlauf.
    PT_ID="$(curl -s -b "$JAR" "$BASE/api/admin/points" | python3 -c 'import json,sys
for e in json.load(sys.stdin):
    if e.get("note") == "Smoke-Test Aufgabe":
        print(e["id"]); break' 2>/dev/null)"
    if [ -n "$PT_ID" ]; then
      check "Punkte wieder zurückgenommen" 204 \
        "$(code -b "$JAR" -X DELETE "$BASE/api/admin/points/$PT_ID")"
    fi
    check "Aufgabe wieder löschen"       204 "$(code -b "$JAR" -X DELETE "$BASE/api/chores/$CHORE_ID")"
  fi

  echo ""
  echo "Dateien"
  # Eine hochgeladene Datei darf der Browser niemals anzeigen, sondern nur
  # speichern. Sonst könnte eine abgelegte HTML-Datei unter der Adresse des
  # Dashboards laufen und an die Sitzung der Familie kommen.
  printf 'Rauchtest\n' > "$JAR.txt"
  UP="$(code -b "$JAR" -F "files=@$JAR.txt;filename=rauchtest.txt" "$BASE/api/files")"
  check "Datei hochladen (nur Admin)"   201 "$UP"
  if [ "$UP" = "201" ]; then
    HEADERS="$(curl -s -D - -o /dev/null -b "$JAR" "$BASE/api/files/rauchtest.txt")"
    check "Datei wird ausgeliefert"     200 \
      "$(printf '%s' "$HEADERS" | sed -n 's|^HTTP/[0-9.]* \([0-9]*\).*|\1|p' | head -1)"
    check "Wird als Anhang geliefert"   ja \
      "$(printf '%s' "$HEADERS" | grep -qi 'content-disposition: *attachment' && echo ja || echo nein)"
    check "Kein Raten des Inhaltstyps"  ja \
      "$(printf '%s' "$HEADERS" | grep -qi 'x-content-type-options: *nosniff' && echo ja || echo nein)"
    check "Datei wieder löschen"        204 \
      "$(code -b "$JAR" -X DELETE "$BASE/api/files/rauchtest.txt")"
  fi
  rm -f "$JAR.txt"

  echo ""
  echo "Musik"
  # Der Index sagt selbst, ob überhaupt etwas eingerichtet ist. Ohne Ordner
  # sind die folgenden Prüfungen sinnlos, also werden sie übersprungen.
  MUSIK="$(curl -s -b "$JAR" "$BASE/api/music/status")"
  MUSIK_AN="$(printf '%s' "$MUSIK" | python3 -c 'import json,sys
d=json.load(sys.stdin); print("ja" if d.get("enabled") and d.get("available") else "nein")' 2>/dev/null || echo nein)"
  check "Musikordner eingerichtet"      ja  "$MUSIK_AN"

  if [ "$MUSIK_AN" = "ja" ]; then
    # Die Wurzel enthält meist nur Ordner. Also so weit hinabsteigen, bis ein
    # Titel auftaucht — höchstens vier Ebenen, dann ist etwas anderes falsch.
    TRACK_ID="$(BASE="$BASE" JAR="$JAR" python3 - <<'PYEOF' 2>/dev/null || true
import json, os, subprocess, urllib.parse

base, jar = os.environ["BASE"], os.environ["JAR"]

def browse(pfad):
    url = f"{base}/api/music/browse?path=" + urllib.parse.quote(pfad)
    roh = subprocess.run(["curl", "-s", "-b", jar, url], capture_output=True, text=True).stdout
    return json.loads(roh)

pfad = ""
for _ in range(4):
    d = browse(pfad)
    if d["tracks"]:
        print(d["tracks"][0]["id"])
        break
    if not d["folders"]:
        break
    pfad = d["folders"][0]["path"]
PYEOF
)"

    if [ -n "$TRACK_ID" ]; then
      check "Titel wird ausgeliefert"     200 \
        "$(code -b "$JAR" "$BASE/api/music/track/$TRACK_ID")"
      # Ohne Bereichsanfragen liesse sich in einem Hörspiel nicht spulen.
      check "Spulen (Bereichsanfrage)"    206 \
        "$(code -b "$JAR" -H 'Range: bytes=0-99' "$BASE/api/music/track/$TRACK_ID")"
    else
      printf '  \033[33m!\033[0m %-46s (kein Titel im Index)\n' "Wiedergabe"
    fi
    check "Unbekannter Titel"            404 "$(code -b "$JAR" "$BASE/api/music/track/999999")"
  else
    echo "  ⚠️  Kein Musikordner — Wiedergabe wird übersprungen."
  fi

  echo ""
  echo "Adminbereich"
  check "Geräteliste"                  200 "$(code -b "$JAR" "$BASE/api/admin/devices")"
  check "Gerät testen (ungültige URL)" 400 \
    "$(code -b "$JAR" -X POST -H 'Content-Type: application/json' \
       -d '{"name":"T","type":"http","url":"kaputt"}' "$BASE/api/admin/devices/test")"

  echo ""
  echo "WebSocket"
  WS="$(curl -s -o /dev/null -w '%{http_code}' -b "$JAR" \
    -H 'Connection: Upgrade' -H 'Upgrade: websocket' \
    -H 'Sec-WebSocket-Version: 13' -H 'Sec-WebSocket-Key: c21va2V0ZXN0MTIzNDU2Nw==' \
    -H "Origin: $BASE" "$BASE/api/shopping/ws")"
  check "Handshake vom eigenen Origin"  101 "$WS"
  WS_EVIL="$(curl -s -o /dev/null -w '%{http_code}' -b "$JAR" \
    -H 'Connection: Upgrade' -H 'Upgrade: websocket' \
    -H 'Sec-WebSocket-Version: 13' -H 'Sec-WebSocket-Key: c21va2V0ZXN0MTIzNDU2Nw==' \
    -H 'Origin: http://angreifer.example' "$BASE/api/shopping/ws")"
  check "Fremder Origin wird blockiert" 403 "$WS_EVIL"
fi

echo ""
if [ "$fail" -eq 0 ]; then
  if [ "$skip" -gt 0 ]; then
    printf '\033[32m✅ %d Prüfungen bestanden\033[0m, \033[33m%d übersprungen\033[0m (keine gültige PIN).\n\n' \
      "$pass" "$skip"
  else
    printf '\033[32m✅ %d Prüfungen bestanden.\033[0m\n\n' "$pass"
  fi
  exit 0
fi
printf '\033[31m❌ %d von %d Prüfungen fehlgeschlagen.\033[0m\n\n' "$fail" "$((pass + fail))"
exit 1
