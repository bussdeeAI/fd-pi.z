import { format, parseISO } from 'date-fns';
import type { WeatherData, WeatherDay } from '$lib/types';

/**
 * Eine Stelle für den Satz, auf den es ankommt. „82 % Regen" beantwortet
 * nicht, ob die Runde noch geht — ein Zeitpunkt tut es. Diashow, Kopfzeile
 * und Wetterseite fragen hier alle gleich nach.
 */
export interface RegenSatz {
  text: string;
  /** true, wenn Regen im Spiel ist — färbt die Zeile blau statt grün. */
  nass: boolean;
}

/** Uhrzeit aus einem ISO-Zeitstempel, robust gegen kaputte Angaben. */
export function uhr(iso: string): string {
  try {
    return format(parseISO(iso), 'HH:mm');
  } catch {
    return '—';
  }
}

/** Millimeter mit deutschem Komma, ohne unnötige Nachkommastellen. */
export function menge(mm: number): string {
  const gerundet = Math.round(mm * 10) / 10;
  if (gerundet === 0) return '0 mm';
  return `${String(gerundet).replace('.', ',')} mm`;
}

/**
 * Das Regenfenster eines Tages als kurze Zeile: „14:00–17:00". Liegen Start
 * und Ende in derselben Stunde, reicht eine Angabe — „um 15:00" liest sich
 * besser als „15:00–15:00".
 */
export function regenFenster(day: WeatherDay): string {
  if (!day.rain_start) return '';
  const start = uhr(day.rain_start);
  if (!day.rain_end || day.rain_start === day.rain_end) return start;
  const ende = uhr(day.rain_end);
  return start === ende ? start : `${start}–${ende}`;
}

export function regenSatz(weather: WeatherData | null | undefined): RegenSatz | null {
  const r = weather?.rain;
  if (!r) return null;

  if (r.now) {
    return r.ends_at
      ? { text: `Es regnet — trocken ab ${uhr(r.ends_at)}`, nass: true }
      : { text: 'Es regnet', nass: true };
  }
  if (r.starts_at) {
    const zeit = uhr(r.starts_at);
    // Ein Fenster aus Viertelstundenwerten ist deutlich sicherer als eine
    // Schätzung aus der Tagesvorschau — das verdient einen anderen Ton.
    if ((r.chance ?? 0) >= 60 || r.fine_grained) {
      return { text: `Regen ab ${zeit}`, nass: true };
    }
    return { text: `Regen möglich ab ${zeit} · ${r.chance ?? 0} %`, nass: true };
  }
  if (r.dry_until) {
    return { text: `Trocken bis ${uhr(r.dry_until)}`, nass: false };
  }
  // Kein Fenster in Sicht: wenigstens sagen, wie nass der Tag überhaupt ist.
  if ((r.chance ?? 0) >= 40) {
    return { text: `Regen möglich (${r.chance} %)`, nass: true };
  }
  return null;
}
