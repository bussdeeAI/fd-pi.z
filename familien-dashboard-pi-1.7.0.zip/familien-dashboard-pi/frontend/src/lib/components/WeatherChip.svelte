<script lang="ts">
  import {
    Cloud, CloudDrizzle, CloudFog, CloudLightning, CloudRain, CloudSnow, CloudSun, Sun,
  } from 'lucide-svelte';
  import { format, parseISO } from 'date-fns';
  import type { WeatherData } from '$lib/types';

  let { weather }: { weather: WeatherData | null } = $props();

  const icons: Record<string, typeof Cloud> = {
    sun: Sun,
    'cloud-sun': CloudSun,
    cloud: Cloud,
    'cloud-drizzle': CloudDrizzle,
    'cloud-rain': CloudRain,
    'cloud-snow': CloudSnow,
    'cloud-fog': CloudFog,
    'cloud-lightning': CloudLightning,
  };

  const Icon = $derived(icons[weather?.current.icon ?? ''] ?? Cloud);

  // Sun in daylight is amber; everything else keeps the calmer accent colour.
  const tone = $derived(
    weather?.current.icon === 'sun' && weather.current.is_day
      ? 'text-amber-500'
      : weather?.current.icon === 'cloud-lightning'
        ? 'text-violet-500'
        : 'text-primary',
  );

  /**
   * Die Kurzzeile unter der Temperatur. Der Regenzeitpunkt schlägt den
   * nackten Prozentwert: „ab 15:00" sagt mehr als „60 %". Der Prozentwert
   * bleibt die Rückfallebene für Tage ohne Fenster.
   */
  const kurzzeile = $derived.by(() => {
    const r = weather?.rain;
    if (!weather) return '';
    if (r?.now) return 'Es regnet';
    if (r?.starts_at) {
      const zeit = uhrKurz(r.starts_at);
      if (zeit) return `Regen ab ${zeit}`;
    }
    const regenHeute = weather.forecast[0]?.precip_probability ?? 0;
    if (regenHeute > 30) return `${regenHeute}% Regen`;
    return weather.current.description;
  });

  // Nur Stunden, keine Versatzfehler über Zeitzonen: Der Chip zeigt einen
  // Kurzzeiger, und parseISO fängt auch hier kaputte Zeiten ab.
  function uhrKurz(iso: string): string {
    try {
      return format(parseISO(iso), 'HH:mm');
    } catch {
      return '';
    }
  }
</script>

{#if weather}
  <a
    href="/wetter"
    class="flex items-center gap-2 rounded-xl px-2 py-1 transition-colors hover:bg-accent"
    title="{weather.current.description} in {weather.location.name} – Details ansehen"
  >
    <Icon class="h-7 w-7 shrink-0 {tone}" />
    <span class="leading-tight">
      <span class="block text-lg font-semibold tabular-nums">
        {Math.round(weather.current.temperature)}°
      </span>
      <span class="block text-[11px] text-muted-foreground">
        {kurzzeile}
      </span>
    </span>
  </a>
{/if}
