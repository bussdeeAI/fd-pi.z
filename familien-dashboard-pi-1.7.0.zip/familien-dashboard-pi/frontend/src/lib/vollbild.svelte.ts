/**
 * Vollbild für die Diashow — der Weg aus dem Browserkorsett.
 *
 * Ein PWA-Manifest mit display:standalone räumt die Adressleiste nur ab,
 * wenn die App wirklich installiert ist. Wer die Diashow im Browser-Tab
 * startet, sah sie sonst weiter. Die Fullscreen-API nimmt sie in jedem Fall:
 * Sie ist ein eigener Benutzerwunsch mit eigener Geste (Klick, Tipp) und
 * verlangt deshalb keine Installation.
 *
 * Safari auf dem iPhone kennt requestFullscreen nur für Video — dort bleibt
 * der Weg über „Zum Home-Bildschirm" (verfuegbar = false, die Diashow zeigt
 * dann einen Tipp statt eines toten Knopfs).
 */
class Vollbild {
  /** true, solange ein Element im Vollbild steht. */
  aktiv = $state(false);
  /** false, wenn der Browser Vollbild gar nicht anbietet (iPhone Safari). */
  verfuegbar = $state(true);

  constructor() {
    if (typeof document === 'undefined') {
      // Serverseite: nichts zu tun, Vorzeichen neutral.
      this.verfuegbar = true;
      return;
    }
    const element = document.documentElement as HTMLElement & {
      webkitRequestFullscreen?: () => Promise<void>;
    };
    this.verfuegbar = typeof element.requestFullscreen === 'function' || typeof element.webkitRequestFullscreen === 'function';

    // Der Zustand gehört dem Browser: F11, Esc, App-Wechsel — alles kann das
    // Vollbild von außen beenden. Wir hören mit, statt es zu erraten.
    const sync = () => (this.aktiv = this.element() !== null);
    document.addEventListener('fullscreenchange', sync);
    document.addEventListener('webkitfullscreenchange', sync);
  }

  private element(): Element | null {
    return (document.fullscreenElement ?? (document as Document & { webkitFullscreenElement?: Element | null }).webkitFullscreenElement) ?? null;
  }

  async ein() {
    if (this.aktiv || !this.verfuegbar) return;
    const element = document.documentElement as HTMLElement & {
      webkitRequestFullscreen?: () => Promise<void>;
    };
    try {
      if (element.requestFullscreen) await element.requestFullscreen({ navigationUI: 'hide' });
      else if (element.webkitRequestFullscreen) await element.webkitRequestFullscreen();
    } catch {
      // Ohne Benutzergeste oder bei abgelehnter Berechtigung bleibt es beim
      // Browser-Tab — die Diashow läuft trotzdem weiter.
    }
  }

  async aus() {
    if (!this.aktiv) return;
    try {
      if (document.exitFullscreen) await document.exitFullscreen();
      else if ((document as Document & { webkitExitFullscreen?: () => Promise<void> }).webkitExitFullscreen) {
        await (document as Document & { webkitExitFullscreen: () => Promise<void> }).webkitExitFullscreen();
      }
    } catch {
      /* schon zu — egal */
    }
  }

  async umschalten() {
    if (this.aktiv) await this.aus();
    else await this.ein();
  }
}

export const vollbild = new Vollbild();
